emptyForm = """
{"form": [
    {
        "type": "message",
        "name": "note",
        "description": "Connect to graphql"
    },
    {
        "name": "url",
        "description": "Graphql URL",
        "type": "string",
        "required": true
    }
]}
"""
