"use strict";
// Implements async functions as Observables
Object.defineProperty(exports, "__esModule", { value: true });
exports.readGoogleSpreadsheet$ = void 0;
const googleapis_1 = require("googleapis");
const rxjs_1 = require("rxjs");
function readGoogleSpreadsheet$(spreadsheetId, sheet, auth) {
    const sheets = googleapis_1.google.sheets({ version: "v4", auth });
    return new rxjs_1.Observable((observer) => {
        sheets.spreadsheets.values.get({
            spreadsheetId,
            range: sheet,
        }, (err, res) => {
            if (err) {
                observer.error(err);
                return;
            }
            const rows = res.data.values;
            observer.next(rows);
            observer.complete();
        });
    });
}
exports.readGoogleSpreadsheet$ = readGoogleSpreadsheet$;
//# sourceMappingURL=observables-googlesheets.js.map