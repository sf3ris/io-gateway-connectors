"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.main = void 0;
const config_1 = require("./config");
const connector_1 = require("./connector");
function main(args) {
    if (!args.credentials) {
        const body = { form: config_1.config.form };
        return { body };
    }
    let credentials = Buffer.from(args.credentials, "base64").toString("ascii");
    let token = Buffer.from(args.token, "base64").toString("ascii");
    return connector_1.readSheetFromSdk(JSON.parse(credentials), JSON.parse(token), args.spreadsheetid, args.sheetname);
}
exports.main = main;
//# sourceMappingURL=index.js.map