"use strict";
// Implements the async functions as Observables
Object.defineProperty(exports, "__esModule", { value: true });
exports.writeFile$ = exports.question$ = exports.readCommandLine$ = exports.readLine$ = exports.readFile$ = void 0;
const fs_1 = require("fs");
const readline = require("readline");
const fs_2 = require("fs");
const rxjs_1 = require("rxjs");
function readFile$(fileName) {
    return new rxjs_1.Observable((observer) => {
        fs_1.readFile(fileName, (err, content) => {
            if (err) {
                observer.error(err);
                return;
            }
            observer.next(content);
            observer.complete();
        });
    });
}
exports.readFile$ = readFile$;
function readLine$(readStream) {
    return new rxjs_1.Observable((observer) => {
        const rl = readline.createInterface({
            input: readStream,
        });
        rl.on("line", (line) => {
            observer.next(line);
        });
        rl.on("close", () => {
            observer.complete();
        });
    });
}
exports.readLine$ = readLine$;
function readCommandLine$() {
    return readLine$(process.stdin);
}
exports.readCommandLine$ = readCommandLine$;
function question$(question, readStream = process.stdin) {
    return new rxjs_1.Observable((observer) => {
        const rl = readline.createInterface({
            input: readStream,
        });
        rl.question(question, (answer) => {
            rl.close();
            observer.next(answer);
            observer.complete();
        });
    });
}
exports.question$ = question$;
function writeFile$(name, data) {
    return new rxjs_1.Observable((observer) => {
        fs_2.writeFile(name, data, (err) => {
            if (err) {
                observer.error(err);
                return;
            }
            observer.next(name);
            observer.complete();
        });
    });
}
exports.writeFile$ = writeFile$;
//# sourceMappingURL=observables.js.map