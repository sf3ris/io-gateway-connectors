"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.rowToRecord = exports.positionToFieldMapper = exports.rowsToRecords = exports.readSheetFromSdk = exports.readSheetRawData$ = exports.readSheet$ = void 0;
const config_1 = require("./config");
const operators_1 = require("rxjs/operators");
const observables_auth_1 = require("./observables-auth");
const observables_googlesheets_1 = require("./observables-googlesheets");
const rxjs_1 = require("rxjs");
/**
 * Reads the records of a specific sheet of a Google worksheet provided that paths to files containing
 * the right credentials and token are passed.
 * HOW TO GET A FRESH TOKEN
 * If the credentials are correct but the token file is not found, a command line dialogue is started. The program respond
 * with a url printed on the terminal. The user has to navigate to that url. After choosing the Google account corresponding
 * to the Credentials, on the browser will appear a string token which needs to be copied and pasted on the command line,
 * after which press ENTER. The program will create a file, under the name originally passed as parameter,
 * containing the token information and will proceed with the rest of the logic, downloading the data.
 *
 * Returns an Observable wich emits an array with all the records read.
 * Each record is an object whose fields contain the values of the corresponding sheet's columns.
 * The mapping from columns to fields is provided in the connector configuration file.
 * @param {string} credentials The path to the file containing the authorization client credentials.
 * @param {string} token The path to the file containing the token data.
 * @param {string} spreadsheetId The id of the preadsheet.
 * @param {string} sheet The name of the sheet to download (if the name contains spaces use double quotes, e.g. "Class Data").
 */
function readSheet$(credentials, token, spreadsheetId, sheet) {
    return readSheetRawData$(credentials, token, spreadsheetId, sheet).pipe(operators_1.map(rowsToRecords));
}
exports.readSheet$ = readSheet$;
function readSheetRawData$(credentials, token, spreadsheetId, sheet) {
    // Read client secrets and token from local files. If token file is not found, launches the procedure to retrieve it
    // from the server and store it on the file system
    return observables_auth_1.oAuth2Client$(credentials, token).pipe(
    // Reads the rows from the specified sheet of the specified Google spreadsheet:
    operators_1.concatMap((authClient) => observables_googlesheets_1.readGoogleSpreadsheet$(spreadsheetId, sheet, authClient)));
}
exports.readSheetRawData$ = readSheetRawData$;
/**
 * Behaves like 'readSheet$' function with the exception that requires regular objects for Credentials and Token and also
 * because it transform the records read from Google sheets to the format expected by the iosdk and returns a
 * Promise out of an Observable
 * @param {any} credentials An object containing the authorization client credentials.
 * @param {any} token An object containing the token data.
 * @param {string} spreadsheetId The id of the preadsheet.
 * @param {string} sheet The name of the sheet to download (if the name contains spaces use double quotes, e.g. "Class Data").
 */
function readSheetFromSdk(credentialsJson, // JSON containing the credentials
tokenJson, // JSON containing the token
spreadsheetId, sheet) {
    const oAuth2Client = observables_auth_1.buildOAuthClientAndSetToken(credentialsJson, tokenJson);
    return observables_googlesheets_1.readGoogleSpreadsheet$(spreadsheetId, sheet, oAuth2Client)
        .pipe(operators_1.map(rowsToRecords), operators_1.map((records) => ({
        body: {
            data: records,
        },
    })), operators_1.catchError((err) => rxjs_1.of({
        body: {
            data: {
                error: `The request has generated an error: ${err}`,
            },
        },
    })))
        .toPromise();
}
exports.readSheetFromSdk = readSheetFromSdk;
/*
 * Private methods - defined as exported (i.e. public) just fortesting reasons
 */
function rowsToRecords(rows) {
    if (rows.length === 0) {
        return null;
    }
    const header = rows[0];
    const { mapper, columnsNotMapped, fieldsNotMapped } = positionToFieldMapper(header, config_1.config.column_field_map);
    if (columnsNotMapped.length > 0) {
        throw new Error(`These columns "${columnsNotMapped}" are not mapped to any field in the message`);
    }
    if (fieldsNotMapped.length > 0) {
        throw new Error(`These fields "${fieldsNotMapped}" are not mapped to any column in the sheet`);
    }
    const rowsWithoutHeader = rows.slice(1);
    const records = rowsWithoutHeader.map((row) => rowToRecord(row, mapper));
    return records;
}
exports.rowsToRecords = rowsToRecords;
function positionToFieldMapper(header, columnFieldMap) {
    const mapper = [];
    const columnsNotMapped = [];
    header.forEach((columnName, i) => {
        const field = columnFieldMap[columnName];
        field
            ? mapper.push({ position: i, field })
            : columnsNotMapped.push(columnName);
    });
    // finds not mapped fields
    const fieldsNotMapped = [];
    const allExpectedFields = Object.values(columnFieldMap);
    const mappedFields = mapper.map((fieldMapper) => fieldMapper.field);
    allExpectedFields.forEach((field) => {
        if (!mappedFields.includes(field)) {
            fieldsNotMapped.push(field);
        }
    });
    return { mapper, columnsNotMapped, fieldsNotMapped };
}
exports.positionToFieldMapper = positionToFieldMapper;
function rowToRecord(row, mapper) {
    const record = {};
    mapper.forEach(({ position, field }) => (record[field] = row[position]));
    return record;
}
exports.rowToRecord = rowToRecord;
//# sourceMappingURL=connector.js.map